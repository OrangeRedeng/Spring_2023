function headmouseon(a) {
    let tdback = document.querySelector(a);
    tdback.style.background = '#99CCFF';
}
function headmouseoff(a) {
    let tdback = document.querySelector(a);
    tdback.style.background = '#0072bc';
}
